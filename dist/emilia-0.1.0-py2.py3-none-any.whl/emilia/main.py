from emilia.emilia import Emilia
import sys

def main() -> int:
    emilia = Emilia("qwen3")
    emilia.talk()

    return 0

if __name__ == "__main__":
    sys.exit(main())
