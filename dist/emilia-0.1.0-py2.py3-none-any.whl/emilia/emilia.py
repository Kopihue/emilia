from ollama import (
    chat,
    Message,
    ChatResponse,
)
from kopilogs.paint import paint

from typing import Sequence

from emilia.tools import (
    search_internet,
    what_time_is_it,
    testing,
)
from emilia.hardcoded import context

class Emilia:
    def __init__(self, model: str):
        self.model = model
        self.context = []
        self._append_context("system", context)
        self.tools = {
            "search_internet": search_internet,
            "testing": testing,
            "what_time_is_it": what_time_is_it,
        }

    def talk(self) -> str:
        while True:
            request = input(paint(">>> ").bold().magenta())
            self._append_context("user", request)

            response = self._generate_content()
            tool_calls = response.message.tool_calls
            content = response.message.content
            self._append_context("assistant", response.message)

            if tool_calls is not None:
                while True:
                    response_tool = self._handle_tool_call(tool_calls)
                    self._append_context("assistant", response_tool.message)

                    if response_tool.message.tool_calls is None:
                        content = response_tool.message.content
                        break

                    tool_calls = response_tool.message.tool_calls

            print()
            paint(">>> ", end="").bold().green().show()
            print(content)
            print()

    def _handle_tool_call(self, tool_calls: Sequence) -> ChatResponse:
        for tc in tool_calls:
            result = self.tools[tc.function.name](**tc.function.arguments)
            self._append_context("tool", result, tool_call=tc.function.name)

        return self._generate_content()

    def _generate_content(self) -> ChatResponse:
        return chat(
            model=self.model,
            messages=self.context,
            tools=list(self.tools.values()),
        )

    def _append_context(
        self,
        role: str,
        content: str | Message,
        tool_call: str | None = None,
    ):
        if type(content) == Message:
            self.context.append(content)
            return

        if role == "tool" and tool_call is not None:
            self.context.append({
                "role": role,
                "tool_name": tool_call,
                "content": content,
            })
            return

        self.context.append({
            "role": role,
            "content": content,
        })
